# Antojo 🌮 — Buscador de restaurantes por antojo

App web ligera: comparte tu ubicación, eliges un platillo y te muestra
restaurantes cercanos con más de 4.2★, con botón directo a Google Maps.

## Arquitectura

```
Móvil (HTML/CSS/JS)  ──POST /api/search──►  Backend Flask  ──►  Google Places API (New)
   geolocalización          (JSON)           (guarda tu API key,        Text Search
   + select de antojo                         filtra rating > 4.2)
```

El backend actúa como **proxy seguro**: tu API key vive solo en el servidor,
nunca llega al navegador.

## Estructura del proyecto

```
antojo/
├── app.py              backend Flask (sirve el front + proxy a Google)
├── requirements.txt
├── render.yaml         despliegue automático en Render
├── .env.example        plantilla de variables
├── .gitignore
└── static/
    ├── index.html
    ├── style.css
    └── app.js
```

## 1. Consigue tu API Key de Google Places

1. Entra a https://console.cloud.google.com/ y crea un proyecto.
2. Menú → **APIs y servicios → Biblioteca** → busca **Places API (New)** → **Habilitar**.
3. **Facturación**: actívala (pide tarjeta, pero **no te cobran** dentro del nivel
   gratuito: Text Search incluye 5,000 llamadas gratis al mes — de sobra para uso
   personal).
4. **Credenciales → Crear credenciales → Clave de API**. Cópiala.
5. (Recomendado) Edita la clave → **Restricciones de API** → limítala solo a
   *Places API (New)*. Como la clave vive en el backend, no necesitas
   restricción por dominio web.

## 2. Probar en local (opcional)

```bash
pip install -r requirements.txt
export GOOGLE_API_KEY="tu_clave"      # en Windows: set GOOGLE_API_KEY=tu_clave
python app.py
```

Abre http://localhost:8080

## 3. Desplegar gratis en Render

Render tiene plan gratuito sin tarjeta (la app "duerme" tras 15 min de
inactividad y tarda ~1 min en despertar la primera vez).

1. Sube esta carpeta a un repositorio de **GitHub**.
2. Crea cuenta en https://render.com y conéctala a GitHub.
3. **New → Web Service** → elige tu repo. Render lee `render.yaml` solo.
   Si lo configuras a mano:
   - Runtime: **Python**
   - Build: `pip install -r requirements.txt`
   - Start: `gunicorn app:app`
   - Plan: **Free**
4. En **Environment** agrega la variable:
   - `GOOGLE_API_KEY` = tu clave (aquí queda segura, nunca en el código).
5. **Create Web Service**. En 2-3 min tendrás una URL `https://antojo-xxxx.onrender.com`.
6. Ábrela en tu móvil. La geolocalización exige HTTPS — Render ya lo da.

### Truco anti-"sueño" (opcional)
Crea un monitor gratis en https://uptimerobot.com que haga ping a tu URL cada
5 min para mantenerla despierta.

## Alternativas de despliegue
- **Render** (recomendado aquí): un solo servicio, lo más simple.
- **Google Cloud Run**: `gcloud run deploy` con la misma carpeta; muy buen plan gratuito, sin sueño.
- **Vercel**: requiere reestructurar el backend como función serverless.

## 4. Instalarla en tu celular (PWA)

La app ya es una **PWA**: una vez en línea (paso 3), se instala con su propio
ícono, sin tiendas.

**Android (Chrome):**
1. Abre tu URL de Render en Chrome.
2. Aparecerá un aviso "Instalar app" / "Agregar a pantalla principal". Tócalo.
   (Si no sale: menú ⋮ → *Instalar aplicación*.)
3. El ícono del taco queda en tu pantalla. Se abre a pantalla completa, sin
   barra del navegador.

**iPhone (Safari):**
1. Abre tu URL en **Safari** (debe ser Safari, no Chrome).
2. Botón compartir (cuadro con flecha ↑) → *Agregar a pantalla de inicio*.
3. Confirma. Listo.

> La geolocalización solo funciona sobre HTTPS — la URL de Render ya lo cumple.

### ¿Quieres un archivo .APK instalable? (solo Android)
1. Entra a https://www.pwabuilder.com
2. Pega tu URL de Render → *Start*.
3. Sección **Android** → *Generate Package* → descargas un `.apk`/`.aab`.
4. Pasa el `.apk` a tu teléfono e instálalo (activa "instalar de orígenes
   desconocidos"). Para Play Store usarías el `.aab`.

## Notas
- El filtro de calidad (`> 4.2★`) está en `app.py` → `MIN_RATING`.
- La búsqueda envía `"<platillo> restaurante"` con sesgo a tus coordenadas y idioma español.
- El botón "Cómo llegar" abre la ruta en Google Maps usando el `place_id` exacto.
